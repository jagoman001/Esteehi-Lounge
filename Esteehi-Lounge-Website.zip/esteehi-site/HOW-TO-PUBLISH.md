# 🚀 How to Publish Esteehi Lounge Website for FREE

Your site URL will be: **https://yourusername.github.io/esteehi-lounge**

---

## STEP 1 — Create a Free GitHub Account
1. Go to https://github.com
2. Click **Sign Up**
3. Choose a username (e.g. esteehilounge)
4. Use your email and create a password
5. Verify your email

---

## STEP 2 — Create a New Repository
1. After logging in, click the **+** icon (top right) → **New repository**
2. Name it: `esteehi-lounge`
3. Make sure it is set to **Public**
4. Click **Create repository**

---

## STEP 3 — Upload Your Files
1. On the new repo page, click **uploading an existing file**
2. Drag and drop your `index.html` file
3. Scroll down, click **Commit changes**

---

## STEP 4 — Enable GitHub Pages
1. Go to your repo **Settings** tab
2. Scroll down to **Pages** (left sidebar)
3. Under **Source**, select **Deploy from a branch**
4. Under **Branch**, choose `main` → `/ (root)` → click **Save**
5. Wait 1–2 minutes

---

## STEP 5 — Your Site is LIVE!
Visit: **https://yourusername.github.io/esteehi-lounge**

Replace `yourusername` with your actual GitHub username.

---

## To Update the Site Later
1. Go to your repo on GitHub
2. Click on `index.html`
3. Click the ✏️ pencil icon to edit
4. Make changes → **Commit changes**
5. Site updates automatically in 1–2 minutes

---

## Optional: Custom Free Domain
If you want `esteehi.netlify.app` instead:
1. Go to https://netlify.com → Sign up free
2. Drag your `index.html` into the deploy box
3. Done! You get a free `.netlify.app` URL instantly

---

*No payment. No credit card. 100% free forever.*
